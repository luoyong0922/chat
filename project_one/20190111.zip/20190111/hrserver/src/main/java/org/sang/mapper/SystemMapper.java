package org.sang.mapper;

/**
 * Created by sang on 2017/12/29.
 */
public interface SystemMapper {

}
