<template>
  <div>
    <h1>
      人事信息统计
    </h1>
  </div>
</template>
