<template>
  <div>
    <h1>员工奖惩</h1>
  </div>
</template>
